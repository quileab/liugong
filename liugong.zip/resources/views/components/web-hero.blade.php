<div>
    <!-- Life is available only in the present moment. - Thich Nhat Hanh -->
</div>