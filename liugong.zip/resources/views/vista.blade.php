<x-layouts.layout>
    <h1>Vista</h1>
    <x-boton>
        
    </x-boton>
</x-layouts.layout>