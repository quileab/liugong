<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $casts = [
        'visible' => 'boolean',
        'featured' => 'boolean',
    ];

    protected $fillable = [
        'category_id',
        'name',
        'price',
        'description',
        'stock_quantity',
        'engine',
        'transmission',
        'drive_type',
        'axles',
        'operative_weight',
        'max_load',
        'load_capacity',
        'dimensions',
        'image',
        'specs',
        'visible',
        'featured',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}
