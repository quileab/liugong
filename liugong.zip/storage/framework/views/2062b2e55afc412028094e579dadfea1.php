<svg class="inline w-5 h-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5"/>
</svg><?php /**PATH E:\Proyectos\liugong\storage\framework\views/5e3c0b07406df2238edb9562b9348c2c.blade.php ENDPATH**/ ?>