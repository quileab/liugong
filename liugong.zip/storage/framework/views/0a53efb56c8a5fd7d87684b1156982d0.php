<div class="bg-gray-100 py-8 px-4 grid grid-cols-1 gap-12 md:grid-cols-3">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal1b11d916ac0b0f70cd138b56a51a5a04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1b11d916ac0b0f70cd138b56a51a5a04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-card','data' => ['title' => $product->name,'image' => $product->image]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name),'image' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->image)]); ?>
            <?php echo e($product->description); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1b11d916ac0b0f70cd138b56a51a5a04)): ?>
<?php $attributes = $__attributesOriginal1b11d916ac0b0f70cd138b56a51a5a04; ?>
<?php unset($__attributesOriginal1b11d916ac0b0f70cd138b56a51a5a04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1b11d916ac0b0f70cd138b56a51a5a04)): ?>
<?php $component = $__componentOriginal1b11d916ac0b0f70cd138b56a51a5a04; ?>
<?php unset($__componentOriginal1b11d916ac0b0f70cd138b56a51a5a04); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH E:\Proyectos\liugong\resources\views/livewire/product-list.blade.php ENDPATH**/ ?>