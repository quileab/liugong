<?php if (isset($component)) { $__componentOriginale8c81e736869ad8b72261906ebaa0e05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8c81e736869ad8b72261906ebaa0e05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalccd10e11e87d3090c00161574d872206 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalccd10e11e87d3090c00161574d872206 = $attributes; } ?>
<?php $component = App\View\Components\WebNavbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WebNavbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalccd10e11e87d3090c00161574d872206)): ?>
<?php $attributes = $__attributesOriginalccd10e11e87d3090c00161574d872206; ?>
<?php unset($__attributesOriginalccd10e11e87d3090c00161574d872206); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalccd10e11e87d3090c00161574d872206)): ?>
<?php $component = $__componentOriginalccd10e11e87d3090c00161574d872206; ?>
<?php unset($__componentOriginalccd10e11e87d3090c00161574d872206); ?>
<?php endif; ?>
    <div class="bg-gray-100 text-gray-900">
    <main class="container mx-auto px-4 py-8" >
        <h1 class="text-3xl text-[var(--color-primary)] font-bold text-center mb-4 animate__animated animate__flipInX">Sobre Nosotros</h1>
        <h2 class="text-xl mb-4 animate__animated animate__fadeInLeft">En Acuña Maquinarias SRL, nos dedicamos a la venta, alquiler y servicio de maquinaria agrícola y de construcción, brindando soluciones integrales a nuestros clientes.</h2>
        <div class="prose lg:prose-xl mx-auto space-y-4 ">
            <p class="animate__animated animate__flipInX animate__delay-1s">Somos una empresa familiar con un fuerte compromiso con el sector productivo. Como concesionario oficial de marcas líderes a nivel mundial como Massey Ferguson, LiuGong y Aolite, ofrecemos una amplia gama de maquinaria de alta calidad y rendimiento.</p>
            <p class="animate__animated animate__flipInX animate__delay-2s">Nuestra actividad principal es la comercialización de maquinaria agrícola y vial, nueva y usada. Además, contamos con un servicio técnico oficial especializado en autoelevadores, garantizando el mantenimiento y la reparación de sus equipos con los más altos estándares.</p>
            <p class="animate__animated animate__flipInX animate__delay-3s">En Acuña Maquinarias SRL, no solo vendemos máquinas, sino que construimos relaciones a largo plazo con nuestros clientes, basadas en la confianza, el asesoramiento profesional y un servicio postventa de excelencia. Nuestro objetivo es ser su socio estratégico, acompañándolo en el crecimiento de su negocio y ofreciéndole las mejores herramientas para optimizar su trabajo.</p>
        </div>
    </main>
    </div>
   <?php if (isset($component)) { $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $attributes = $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $component = $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8c81e736869ad8b72261906ebaa0e05)): ?>
<?php $attributes = $__attributesOriginale8c81e736869ad8b72261906ebaa0e05; ?>
<?php unset($__attributesOriginale8c81e736869ad8b72261906ebaa0e05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8c81e736869ad8b72261906ebaa0e05)): ?>
<?php $component = $__componentOriginale8c81e736869ad8b72261906ebaa0e05; ?>
<?php unset($__componentOriginale8c81e736869ad8b72261906ebaa0e05); ?>
<?php endif; ?><?php /**PATH E:\Proyectos\liugong\resources\views/about.blade.php ENDPATH**/ ?>