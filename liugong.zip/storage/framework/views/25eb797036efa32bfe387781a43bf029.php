    <div x-data="{
        slides: <?php echo \Illuminate\Support\Js::from($slides)->toHtml() ?>,
        withoutIndicators: <?php echo e(json_encode($withoutIndicators)); ?>,
        autoplay: <?php echo e(json_encode($autoplay)); ?>,
        interval: <?php echo e(json_encode($interval)); ?>,
        currentSlideIndex: 1,
        touchStartX: null,
        touchEndX: null,
        swipeThreshold: 50,
        previous() {
            this.currentSlideIndex = (this.currentSlideIndex > 1)
                ? --this.currentSlideIndex
                : this.slides.length
        },
        next() {
            this.currentSlideIndex = (this.currentSlideIndex < this.slides.length)
                ? ++this.currentSlideIndex
                : 1
        },
        handleTouchStart(event) {
            this.touchStartX = event.touches[0].clientX
        },
        handleTouchMove(event) {
            this.touchEndX = event.touches[0].clientX
        },
        handleTouchEnd() {
            if(this.touchEndX){
                if (this.touchStartX - this.touchEndX > this.swipeThreshold) {
                    this.next()
                }
                if (this.touchStartX - this.touchEndX < -this.swipeThreshold) {
                    this.previous()
                }
                this.touchStartX = null
                this.touchEndX = null
            }
        },
        init() {
            if (this.autoplay)
                setInterval(() => { this.next(); }, this.interval);
        }
    }" class="relative w-full overflow-hidden">

        <?php if(!$withoutArrows): ?>
            <!-- previous button -->
            <?php if (isset($component)) { $__componentOriginal602b228a887fab12f0012a3179e5b533 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal602b228a887fab12f0012a3179e5b533 = $attributes; } ?>
<?php $component = Mary\View\Components\Button::resolve(['icon' => 'o-chevron-left'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click' => 'previous()','class' => 'absolute cursor-pointer left-5 top-1/2 z-[2] btn-circle btn-sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $attributes = $__attributesOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__attributesOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $component = $__componentOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__componentOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
            <!-- next button -->
            <?php if (isset($component)) { $__componentOriginal602b228a887fab12f0012a3179e5b533 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal602b228a887fab12f0012a3179e5b533 = $attributes; } ?>
<?php $component = Mary\View\Components\Button::resolve(['icon' => 'o-chevron-right'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click' => 'next()','class' => 'absolute cursor-pointer right-5 top-1/2 z-[2] btn-circle btn-sm']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $attributes = $__attributesOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__attributesOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal602b228a887fab12f0012a3179e5b533)): ?>
<?php $component = $__componentOriginal602b228a887fab12f0012a3179e5b533; ?>
<?php unset($__componentOriginal602b228a887fab12f0012a3179e5b533); ?>
<?php endif; ?>
        <?php endif; ?>

        <!-- slides -->
        <div
             @touchstart="handleTouchStart($event)" @touchmove="handleTouchMove($event)" @touchend="handleTouchEnd()"
            <?php echo e($attributes->class(["relative h-64 w-full rounded-box overflow-hidden"])); ?>

        >
            <!-- Slot content -->
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    x-cloak
                    x-show="currentSlideIndex == <?php echo e($index + 1); ?>"
                    x-transition.opacity.duration.500ms
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses(["absolute inset-0", "cursor-pointer" => data_get($slide, 'url') ]); ?>"
                    <?php if(data_get($slide, 'url')): ?>
                        @click="window.location = '<?php echo e(data_get($slide, 'url')); ?>'"
                    <?php endif; ?>
                >
                    <!-- Custom content -->
                    <?php if($content): ?>
                        <div class="absolute inset-0 z-[1]">
                             <?php echo e($content($slide)); ?>

                        </div>
                    <!-- Default content -->
                    <?php else: ?>
                          <div
                              class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                  "absolute inset-0 z-[1] flex flex-col items-center justify-end gap-2 px-20 py-12 text-center",
                                   "bg-gradient-to-t from-slate-900/85" => data_get($slide, 'urlText') || data_get($slide, 'title') || data_get($slide, 'description')
                              ]); ?>"
                        >
                            <!-- Title -->
                            <h3 class="w-full text-2xl lg:text-3xl font-bold text-white"><?php echo e(data_get($slide, 'title')); ?></h3>

                            <!-- Description -->
                            <div class="w-full text-sm text-white mb-5"><?php echo e(data_get($slide, 'description')); ?></div>

                            <!-- Button-->
                            <?php if(data_get($slide, 'urlText')): ?>
                                <a href="<?php echo e(data_get($slide, 'url')); ?>" class="btn btn-sm btn-outline text-white border-white hover:bg-transparent my-3 hover:scale-105"><?php echo e(data_get($slide, 'urlText')); ?></a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Image -->
                    <img class="w-full h-full inset-0 object-cover" src="<?php echo e(data_get($slide, 'image')); ?>" />
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- indicators -->
        <?php if(! $withoutIndicators): ?>
            <div class="absolute rounded-xl bottom-3 md:bottom-5 left-1/2 z-[2] flex -translate-x-1/2 gap-4 md:gap-3 bg-base-300 px-1.5 py-1 md:px-2" role="group" aria-label="slides" >
                <template x-for="(slide, index) in slides">
                    <button class="size-2.5 cursor-pointer rounded-full transition hover:scale-125" @click="currentSlideIndex = index + 1" :class="[currentSlideIndex === index + 1 ? 'bg-base-content' : 'bg-base-content/30']"></button>
                </template>
            </div>
        <?php endif; ?>
    </div><?php /**PATH E:\Proyectos\liugong\storage\framework\views/3bbb7f2669a67118968f05cc99b0c454.blade.php ENDPATH**/ ?>