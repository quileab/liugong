<?php if (isset($component)) { $__componentOriginale8c81e736869ad8b72261906ebaa0e05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8c81e736869ad8b72261906ebaa0e05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalccd10e11e87d3090c00161574d872206 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalccd10e11e87d3090c00161574d872206 = $attributes; } ?>
<?php $component = App\View\Components\WebNavbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WebNavbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalccd10e11e87d3090c00161574d872206)): ?>
<?php $attributes = $__attributesOriginalccd10e11e87d3090c00161574d872206; ?>
<?php unset($__attributesOriginalccd10e11e87d3090c00161574d872206); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalccd10e11e87d3090c00161574d872206)): ?>
<?php $component = $__componentOriginalccd10e11e87d3090c00161574d872206; ?>
<?php unset($__componentOriginalccd10e11e87d3090c00161574d872206); ?>
<?php endif; ?>
    <div class="bg-gray-100 text-gray-900">
    <main class="container mx-auto px-4 py-8">
        <h1 class="text-3xl text-[var(--color-primary)] font-bold text-center mb-4 animate__animated animate__flipInX">Contacto</h1>
        <div class="max-w-2xl mx-auto">
            <p class="text-lg mb-4 animate__animated animate__fadeInLeft">¿Tienes alguna pregunta o quieres saber más sobre nuestros productos? Completa el siguiente formulario y nos pondremos en contacto contigo a la brevedad.</p>
            <form action="#" method="POST" class="space-y-6">
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">Nombre</label>
                    <div class="mt-1">
                        <input type="text" name="name" id="name" autocomplete="name" class="py-3 px-4 block w-full shadow-sm focus:ring-primary focus:border-primary border-gray-300 rounded-md">
                    </div>
                </div>
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                    <div class="mt-1">
                        <input id="email" name="email" type="email" autocomplete="email" class="py-3 px-4 block w-full shadow-sm focus:ring-primary focus:border-primary border-gray-300 rounded-md">
                    </div>
                </div>
                <div>
                    <label for="message" class="block text-sm font-medium text-gray-700">Mensaje</label>
                    <div class="mt-1">
                        <textarea id="message" name="message" rows="4" class="py-3 px-4 block w-full shadow-sm focus:ring-primary focus:border-primary border-gray-300 rounded-md"></textarea>
                    </div>
                </div>
                <div>
                    <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                        Enviar Mensaje
                    </button>
                </div>
            </form>
        </div>
    </main>
    </div>
   <?php if (isset($component)) { $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $attributes = $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $component = $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8c81e736869ad8b72261906ebaa0e05)): ?>
<?php $attributes = $__attributesOriginale8c81e736869ad8b72261906ebaa0e05; ?>
<?php unset($__attributesOriginale8c81e736869ad8b72261906ebaa0e05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8c81e736869ad8b72261906ebaa0e05)): ?>
<?php $component = $__componentOriginale8c81e736869ad8b72261906ebaa0e05; ?>
<?php unset($__componentOriginale8c81e736869ad8b72261906ebaa0e05); ?>
<?php endif; ?>
<?php /**PATH E:\Proyectos\liugong\resources\views/contact.blade.php ENDPATH**/ ?>