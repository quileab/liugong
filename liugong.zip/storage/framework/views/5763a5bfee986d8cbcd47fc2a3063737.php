<?php if (isset($component)) { $__componentOriginale8c81e736869ad8b72261906ebaa0e05 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8c81e736869ad8b72261906ebaa0e05 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalccd10e11e87d3090c00161574d872206 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalccd10e11e87d3090c00161574d872206 = $attributes; } ?>
<?php $component = App\View\Components\WebNavbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\WebNavbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalccd10e11e87d3090c00161574d872206)): ?>
<?php $attributes = $__attributesOriginalccd10e11e87d3090c00161574d872206; ?>
<?php unset($__attributesOriginalccd10e11e87d3090c00161574d872206); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalccd10e11e87d3090c00161574d872206)): ?>
<?php $component = $__componentOriginalccd10e11e87d3090c00161574d872206; ?>
<?php unset($__componentOriginalccd10e11e87d3090c00161574d872206); ?>
<?php endif; ?>

<?php
    $slides = [
        [
            'image' => 'https://www.liugong.com/wp-content/uploads/2023/04/0222pc-update.jpg',
            'title' => 'Frontend developers',
            'description' => 'We love last week frameworks.',
            'url' => '/docs/installation',
            'urlText' => 'Get started',
        ],
        [
            'image' => 'https://www.liugong.com/wp-content/uploads/2023/04/banner-0930-PC.jpg',
            'title' => 'Full stack developers',
            'description' => 'Where burnout is just a fancy term for Tuesday.',
        ],
        [
            'image' => 'https://www.liugong.com/wp-content/uploads/2025/03/bauma-pc.jpg',
            'url' => '/docs/installation',
            'urlText' => 'Let`s go!',
        ],
        [
            'image' => 'https://www.liugong.com/wp-content/uploads/2023/09/856e-banner-pc.jpg',
            'url' => '/docs/installation',
        ],
    ];
?>
 
<?php if (isset($component)) { $__componentOriginal37bbed78a520e56e0ac01c7aed8da634 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal37bbed78a520e56e0ac01c7aed8da634 = $attributes; } ?>
<?php $component = Mary\View\Components\Carousel::resolve(['slides' => $slides,'autoplay' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carousel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Mary\View\Components\Carousel::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal37bbed78a520e56e0ac01c7aed8da634)): ?>
<?php $attributes = $__attributesOriginal37bbed78a520e56e0ac01c7aed8da634; ?>
<?php unset($__attributesOriginal37bbed78a520e56e0ac01c7aed8da634); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37bbed78a520e56e0ac01c7aed8da634)): ?>
<?php $component = $__componentOriginal37bbed78a520e56e0ac01c7aed8da634; ?>
<?php unset($__componentOriginal37bbed78a520e56e0ac01c7aed8da634); ?>
<?php endif; ?>
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('search-component', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3595439784-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <main>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('product-list', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3595439784-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </main>
   <?php if (isset($component)) { $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.web-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('web-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $attributes = $__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__attributesOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4)): ?>
<?php $component = $__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4; ?>
<?php unset($__componentOriginalf978ae35c4070f2ea75ad3f3b050eef4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8c81e736869ad8b72261906ebaa0e05)): ?>
<?php $attributes = $__attributesOriginale8c81e736869ad8b72261906ebaa0e05; ?>
<?php unset($__attributesOriginale8c81e736869ad8b72261906ebaa0e05); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8c81e736869ad8b72261906ebaa0e05)): ?>
<?php $component = $__componentOriginale8c81e736869ad8b72261906ebaa0e05; ?>
<?php unset($__componentOriginale8c81e736869ad8b72261906ebaa0e05); ?>
<?php endif; ?><?php /**PATH E:\Proyectos\liugong\resources\views/index.blade.php ENDPATH**/ ?>