<div class="inno-card p-0 overflow-hidden flex flex-col">
    <h2 class="text-2xl font-bold mb-4 text-primary p-4"><?php echo e($title); ?></h2>
    <!--[if BLOCK]><![endif]--><?php if(isset($image)): ?>
        <img src="<?php echo e($image); ?>" alt="<?php echo e($title); ?>" class="w-full h-auto flex-1 aspect-video object-contain">
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <p class="text-lg md:text-sm text-white bg-secondary p-6 h-32 "><?php echo e($slot); ?></p>
    <!--[if BLOCK]><![endif]--><?php if(isset($footer)): ?>
        <div class="mt-4">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH E:\Proyectos\liugong\resources\views/components/web-card.blade.php ENDPATH**/ ?>